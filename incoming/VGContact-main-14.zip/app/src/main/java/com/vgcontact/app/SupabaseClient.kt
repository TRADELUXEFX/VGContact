package com.vgcontact.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

object SupabaseClient {
    private val supabaseUrl = BuildConfig.SUPABASE_URL
    private val anonKey = BuildConfig.SUPABASE_ANON_KEY
    // 30 s instead of OkHttp's 10 s default, so a slow mobile connection can finish the call.
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    // True only if the app was actually built with real Supabase credentials.
    // If SUPABASE_URL / SUPABASE_ANON_KEY were blank at build time (missing
    // local.properties or missing CI secrets), every call below fails cleanly
    // through this check instead of crashing on a malformed URL.
    private fun isConfigured(): Boolean {
        return supabaseUrl.isNotBlank() && anonKey.isNotBlank() && supabaseUrl.startsWith("http")
    }

    // Cheap connectivity check before spending a request on a device
    // that's plainly offline (e.g. airplane mode).
    fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    // Calls a Postgres function (RPC) with the anon key and returns the
    // parsed JSON array, or null on any failure. All table access for
    // private data now goes through these functions; the database no longer
    // lets the anon key read or write those tables directly.
    // Last failure reason from rpc(), so screens can show something more
    // useful than a guess. Cleared at the start of every call.
    @Volatile
    var lastError: String? = null
        private set

    // Functions that act for a signed-in user. rpc() adds the account secret to every one of
    // them, so the screens never have to. Without the right secret the server answers UNAUTHORIZED.
    private val SECRET_RPCS = setOf(
        "get_app_bundle", "get_home", "get_today_repost_status", "get_today_verify_status",
        "get_sync_contacts", "get_removed_numbers", "get_my_referrals_full", "get_referral_leaderboard_phone",
        "get_referral_leaderboard", "get_repost_leaderboard_phone", "get_leaderboard",
        "open_notifications", "mark_notifications_read", "record_notification_delivered",
        "record_notification_opened", "report_notifications_enabled", "save_fcm_token",
        "record_sync", "report_sync_device", "get_sync_adapter_enabled", "get_my_profile", "get_my_referrer", "submit_daily_repost"
    )

    private fun currentSecret(): String =
        VGApp.instance?.let { SessionManager(it).getSecret() } ?: ""

    // The server no longer accepts this phone's secret (account reset, or an old install):
    // clear the saved login and send the user to the first screen to sign in again.
    private fun handleUnauthorized() {
        val app = VGApp.instance ?: return
        val sm = SessionManager(app)
        if (sm.getUserId().isNullOrBlank()) return
        sm.logout()
        try {
            app.startActivity(
                android.content.Intent(app, RegisterActivity::class.java)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
        } catch (e: Exception) {
            // Started from the background: the next time the app opens it shows sign-in.
        }
    }

    // ---- Plain-language messages for server errors --------------------------------
    // Rule: users never see raw server text ("HTTP 400: {...}"). Every screen that shows a
    // failure goes through one of these. Codes come from the SQL (see
    // supabase/migrations/check_error_codes.sql to list every code the database can send).

    /** True when the server refused a new account because registrations are switched off. */
    fun isSignupClosed(err: String?): Boolean {
        if (err.isNullOrBlank()) return false
        if (err.contains("REGISTRATIONS_CLOSED", ignoreCase = true)) return true
        val about = listOf("regist", "sign up", "signup", "sign-up").any { err.contains(it, true) }
        val state = listOf("closed", "paus", "disabled", "not open", "locked", "stopped", "suspend")
            .any { err.contains(it, true) }
        return about && state
    }

    /** Message for a failed call, from lastError. [what] completes "Couldn't ...". */
    fun userMessage(err: String?, what: String): String {
        val e = err.orEmpty()
        return when {
            e.isBlank() -> "Couldn't $what. Please try again."
            e.startsWith("Network error") -> "Couldn't reach the server. Check your internet and try again."
            isSignupClosed(e) -> "Registration is paused right now. Please try again later."
            e.contains("INVALID_INPUT") -> "Please check the details you entered and try again."
            e.contains("UNAUTHORIZED") -> "Your session expired. Please log out and log in again."
            e.contains("ACCOUNT_BANNED") -> "This account has been banned."
            e.startsWith("HTTP 429") -> "Too many attempts. Please wait a moment and try again."
            e.startsWith("HTTP 5") -> "Our server is having a problem. Please try again in a few minutes."
            e.contains("missing its server settings") -> "This version of the app isn't set up correctly. Please update the app."
            else -> "Couldn't $what. Please try again."
        }
    }

    /** Message for a code returned by submit_daily_repost, or null if there is no specific one. */
    fun messageForCode(code: String?): String? = when (code) {
        "NOT_VERIFIED" -> "Get verified first: post your invite on your status and send us the screenshot."
        "ALREADY_VERIFIED" -> "You're already verified. You can start reposting."
        "REPOST_LIMIT_REACHED" -> "You've reached your repost limit, so there's nothing more to post right now."
        "USER_NOT_FOUND" -> "We couldn't find your account. Please log out and log in again."
        "NO_INTERNET" -> "Couldn't reach the server. Check your internet and try again."
        else -> null
    }

    private fun rpc(name: String, params: JSONObject): org.json.JSONArray? {
        lastError = null
        if (name in SECRET_RPCS) params.put("p_secret", currentSecret())
        if (!isConfigured()) {
            lastError = "App is missing its server settings (build has no Supabase URL/key)."
            return null
        }
        return try {
            val request = Request.Builder()
                .url("$supabaseUrl/rest/v1/rpc/$name")
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $anonKey")
                .addHeader("Content-Type", "application/json")
                .post(params.toString().toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    org.json.JSONArray(if (body.isBlank()) "[]" else body)
                } else {
                    if (body.contains("UNAUTHORIZED")) handleUnauthorized()
                    if (body.contains("ACCOUNT_BANNED")) {
                        BannedHandler.trigger(if (params.isNull("p_phone")) null else params.optString("p_phone").ifBlank { null })
                    }
                    lastError = "HTTP ${response.code}: " + body.take(160)
                    null
                }
            }
        } catch (e: Exception) {
            lastError = "Network error: " + (e.message ?: e.javaClass.simpleName)
            null
        }
    }

    // No password, no Supabase auth session. Sign-up and login return the account's SECRET,
    // which the app keeps and sends with every later call (see SECRET_RPCS).
    // register_account (server side, wraps register_or_fetch_user) either returns the existing
    // account for this device or creates one and drops it into a contact
    // group. A duplicate username/phone makes the call fail, which the
    // caller shows as "may already be registered".
    fun registerOrFetchUser(
        androidId: String,
        username: String,
        phone: String,
        referredBy: String?,
        callback: (Boolean, JSONObject?) -> Unit
    ) {
        val params = JSONObject().apply {
            put("p_android_id", androidId)
            put("p_username", username)
            put("p_phone", phone)
            put("p_referred_by", if (referredBy.isNullOrBlank()) JSONObject.NULL else referredBy)
        }
        val arr = rpc("register_account", params)
        if (arr != null && arr.length() > 0) callback(true, arr.getJSONObject(0)) else callback(false, null)
    }

    // Looks an account up by phone number and confirms this device's
    // android_id matches the one on file (no OTP, no password). The server
    // does the comparison and only returns account data when the device
    // matches, so a different device learns nothing about the account.
    fun fetchUserByPhone(
        phone: String,
        androidId: String,
        callback: (found: Boolean, deviceMatches: Boolean, user: JSONObject?) -> Unit
    ) {
        val params = JSONObject().apply {
            put("p_phone", phone)
            put("p_android_id", androidId)
        }
        val arr = rpc("login_account", params)
        if (arr == null || arr.length() == 0) {
            callback(false, false, null)
            return
        }
        val row = arr.getJSONObject(0)
        val exists = row.optBoolean("account_exists", false)
        val matches = row.optBoolean("device_matches", false)
        callback(exists, matches, if (exists && matches) row else null)
    }

    // Is this account / phone / device banned? Never errors on a ban itself:
    // callback(null, null) means "couldn't tell" (offline / server error).
    fun getBanStatus(userId: String?, phone: String?, androidId: String?, callback: (Boolean?, String?) -> Unit) {
        val params = JSONObject().apply {
            put("p_user_id", userId ?: JSONObject.NULL)
            put("p_phone", phone ?: JSONObject.NULL)
            put("p_android_id", androidId ?: JSONObject.NULL)
        }
        val arr = rpc("get_ban_status", params)
        if (arr == null || arr.length() == 0) { callback(null, null); return }
        val row = arr.getJSONObject(0)
        callback(row.optBoolean("banned", false), if (row.isNull("reason")) null else row.optString("reason").ifBlank { null })
    }

    // Records today's repost attempt as 'pending'. It only becomes
    // 'verified' once the admin checks it against WhatsApp status viewers
    // and marks it in the daily_reposts table. One attempt
    // per calendar day is enforced both here (via the RPC's own check) and
    // by a unique index on (user_id, repost_date), so a double-tap can't
    // queue two pending rows.
    //
    // message is one of: "OK", "ALREADY_REPOSTED_TODAY", or a raw error.
    // kind = "verify" (pending sheet, first task) or "repost" (Repost screen, verified users).
    // Extra messages: ALREADY_VERIFIED, NOT_VERIFIED, REPOST_LIMIT_REACHED.
    fun submitDailyRepost(userId: String, kind: String = "repost", callback: (Boolean, String) -> Unit) {
        val arr = rpc("submit_daily_repost", JSONObject().apply {
            put("p_user_id", userId)
            put("p_kind", kind)
        })
        when {
            arr == null -> callback(false, when {
                !isConfigured() -> "NOT_CONFIGURED"
                lastError?.startsWith("Network error") == true -> "NO_INTERNET"
                else -> "REQUEST_FAILED"
            })
            arr.length() == 0 -> callback(false, "EMPTY_RESPONSE")
            else -> {
                val row = arr.getJSONObject(0)
                callback(row.optBoolean("success", false), row.optString("message", "OK"))
            }
        }
    }

    // Today's verification (first task) status: null, "pending", "verified" or "rejected".
    fun fetchTodayVerifyStatus(userId: String, callback: (Boolean, String?) -> Unit) {
        val arr = rpc("get_today_verify_status", JSONObject().apply { put("p_user_id", userId) })
        if (arr == null) {
            callback(false, null)
            return
        }
        callback(true, if (arr.length() > 0) arr.getJSONObject(0).optString("status") else null)
    }

    // ---- Home + Sync contacts (viewers model) ----

    // What the Home card shows. status is "pending" or "verified".
    // Free = the default group from signup. Extra = every other group.
    // Referral = a plain count (no cap).
    data class HomeData(
        val status: String,
        val freeCurrent: Int,
        val freeMax: Int,
        val extraCurrent: Int,
        val extraMax: Int,
        val referralCount: Int,
        val verifiedReposts: Int
    )

    // Everything Home and Repost need, in ONE call (get_app_bundle):
    // account status + viewers, unread dot, ban, app update, community link, today's repost.
    // Blocking: call from a background thread. Null = failed (see lastError).
    data class AppBundle(
        val home: HomeData?,
        val hasUnread: Boolean,
        val banned: Boolean,
        val banReason: String?,
        val update: JSONObject?,
        val communityLink: String?,
        val todayRepostStatus: String?,
        // Pending-sheet / pay-screen numbers (app_settings) and today's verify status,
        // so opening the verify sheet needs no extra calls.
        val settings: JSONObject? = null,
        val todayVerifyStatus: String? = null
    )

    fun fetchBundle(context: Context): AppBundle? {
        val sm = SessionManager(context)
        val userId = sm.getUserId()
        if (userId.isNullOrBlank()) return null
        val params = JSONObject().apply {
            put("p_user_id", userId)
            put("p_phone", sm.getPhone() ?: JSONObject.NULL)
            put("p_android_id", BannedHandler.androidId(context))
            put("p_current_build", AppUpdatePrompt.currentBuild())
        }
        // Read-only call, so it is safe to try once more after a network failure (timeout etc.).
        var arr = rpc("get_app_bundle", params)
        if (arr == null && lastError?.startsWith("Network error") == true) {
            arr = rpc("get_app_bundle", params)
        }
        if (arr == null || arr.length() == 0) return null
        val b = arr.getJSONObject(0).optJSONObject("bundle") ?: return null
        val h = b.optJSONObject("home")
        fun text(key: String): String? = if (b.isNull(key)) null else b.optString(key).ifBlank { null }
        return AppBundle(
            home = h?.let {
                HomeData(
                    status = it.optString("status", "pending"),
                    freeCurrent = it.optInt("free_current", 0),
                    freeMax = it.optInt("free_max", 0),
                    extraCurrent = it.optInt("extra_current", 0),
                    extraMax = it.optInt("extra_max", 0),
                    referralCount = it.optInt("referral_count", 0),
                    verifiedReposts = it.optInt("verified_reposts", 0)
                )
            },
            hasUnread = b.optBoolean("has_unread", false),
            banned = b.optBoolean("banned", false),
            banReason = text("ban_reason"),
            update = b.optJSONObject("update"),
            communityLink = text("community_link"),
            todayRepostStatus = text("today_repost_status"),
            settings = b.optJSONObject("settings"),
            todayVerifyStatus = text("today_verify_status")
        )
    }

    // isSystem = the admin number and the status number. They are saved with their plain
    // name (no VGC<N> ending); only group members and the referral chain get the tag.
    data class SyncContact(val phone: String, val name: String, val isSystem: Boolean = false)

    // Every contact this user should have on the phone, already named by
    // the server. Blocking - call from a background thread. Null = failed.
    fun fetchSyncContacts(userId: String): List<SyncContact>? {
        val arr = rpc("get_sync_contacts", JSONObject().apply { put("p_user_id", userId) }) ?: return null
        val out = mutableListOf<SyncContact>()
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            out.add(SyncContact(r.optString("phone"), r.optString("display_name"), r.optBoolean("is_system", false)))
        }
        return out
    }

    // Numbers the admin asked to delete from every phone (any saved name). Null = failed;
    // callers treat that like an empty list.
    fun fetchRemovedNumbers(userId: String): List<String>? {
        val arr = rpc("get_removed_numbers", JSONObject().apply { put("p_user_id", userId) }) ?: return null
        val out = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val n = arr.getJSONObject(i).optString("phone")
            if (n.isNotBlank()) out.add(n)
        }
        return out
    }

    // One person in a referral list (see get_my_referrals). invitedCount =
    // how many people that person referred themselves.
    data class MyReferral(
        val userId: String,
        val username: String,
        val phone: String,
        val createdAt: String,
        val invitedCount: Int,
        // True while the person has not been verified yet (still waiting for approval).
        // False when verified, or when the server could not tell (older server).
        val isPending: Boolean = false
    )

    // The people one user referred. targetUserId = null gives the caller's own
    // list; a downline member's id gives that person's list (the server only
    // answers for people inside the caller's own levels). Blocking - call from
    // a background thread. Null = failed.
    fun fetchMyReferrals(userId: String, targetUserId: String?): List<MyReferral>? {
        val params = JSONObject().apply {
            put("p_user_id", userId)
            put("p_target_user_id", if (targetUserId.isNullOrBlank()) JSONObject.NULL else targetUserId)
        }
        // ONE call (get_my_referrals_full): the list and each person's verified flag together.
        val arr = rpc("get_my_referrals_full", params) ?: return null
        val out = mutableListOf<MyReferral>()
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            out.add(
                MyReferral(
                    userId = r.optString("user_id"),
                    username = r.optString("username"),
                    phone = r.optString("phone"),
                    createdAt = r.optString("created_at"),
                    invitedCount = r.optInt("invited_count", 0),
                    isPending = !r.optBoolean("is_verified", true)
                )
            )
        }
        return out
    }

    data class LeaderboardEntry(val username: String, val referralCount: Int, val isMe: Boolean, val phone: String = "")

    // Top 50 referrers by direct referrals, shown by phone number. Null = failed.
    fun fetchReferralLeaderboard(userId: String): List<LeaderboardEntry>? {
        val params = JSONObject().apply { put("p_user_id", userId) }
        val arr = rpc("get_referral_leaderboard_phone", params)
            ?: rpc("get_referral_leaderboard", params) ?: return null
        val out = mutableListOf<LeaderboardEntry>()
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            out.add(LeaderboardEntry(r.optString("username"), r.optInt("referral_count", 0), r.optBoolean("is_me", false), r.optString("phone")))
        }
        return out
    }

    // One row of the repost leaderboard. score = verified reposts. Username, plus phone when the server sends it (get_repost_leaderboard_phone).
    data class RepostBoardEntry(
        val rank: Int,
        val userId: String,
        val username: String,
        val score: Int,
        val isMe: Boolean,
        val phone: String = ""
    )

    // Repost leaderboard via get_leaderboard. metric = "reposts" (the only one the server accepts);
    // all-time, top 50 plus the caller's own row even when outside the top.
    // Blocking - call from a background thread. Null = failed.
    fun fetchRepostLeaderboard(userId: String, metric: String): List<RepostBoardEntry>? {
        val params = JSONObject().apply {
            put("p_user_id", userId)
            put("p_metric", metric)
            put("p_period", "all")
            put("p_limit", 50)
        }
        val arr = rpc("get_repost_leaderboard_phone", JSONObject().apply { put("p_user_id", userId) })
            ?: rpc("get_leaderboard", params) ?: return null
        val out = mutableListOf<RepostBoardEntry>()
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            out.add(
                RepostBoardEntry(
                    rank = r.optInt("rank", i + 1),
                    userId = r.optString("user_id"),
                    username = r.optString("username"),
                    score = r.optInt("score", 0),
                    isMe = r.optBoolean("is_me", false),
                    phone = r.optString("phone")
                )
            )
        }
        return out
    }

    // A notification the user can see: their own targeted rows (a group
    // they're in became full) plus every broadcast row (any group filled).
    data class AppNotification(
        val id: String,
        val title: String,
        val body: String,
        val createdAt: String,
        val isRead: Boolean,
        val action: String? = null,
        val target: String? = null
    )

    // Up to the 50 most recent notifications visible to this user, via the
    // fetch_notifications RPC (SECURITY DEFINER - direct table reads are
    // blocked by RLS, see notifications_schema.sql).
    fun fetchNotifications(userId: String, callback: (Boolean, List<AppNotification>) -> Unit) {
        // ONE call: returns the list, then marks everything read on the server.
        val arr = rpc("open_notifications", JSONObject().apply { put("p_user_id", userId) })
        if (arr == null) {
            callback(false, emptyList())
            return
        }
        val notifications = mutableListOf<AppNotification>()
        for (i in 0 until arr.length()) {
            val row = arr.getJSONObject(i)
            notifications.add(
                AppNotification(
                    id = row.optString("id"),
                    title = row.optString("title"),
                    body = row.optString("body"),
                    createdAt = row.optString("created_at"),
                    isRead = row.optBoolean("is_read", false),
                    action = row.optString("action", "").ifBlank { null },
                    target = row.optString("target", "").ifBlank { null }
                )
            )
        }
        callback(true, notifications)
    }

    // Saves this device's current FCM token onto the user's row so the
    // send-push Edge Function knows where to deliver notifications. Called
    // on login/register and whenever FCM refreshes the token. Best-effort.
    fun saveFcmToken(userId: String, token: String, callback: (Boolean) -> Unit) {
        val params = JSONObject().apply {
            put("p_user_id", userId)
            put("p_token", token)
        }
        // Network calls must not run on the main thread, and the callers
        // (cold start, post-login flush) are on it - so hop off here.
        kotlin.concurrent.thread {
            callback(rpc("save_fcm_token", params) != null)
        }
    }

    // "I just synced": stamps users.last_synced_at so the server knows this
    // user is active (see add_inactivity.sql). Fire-and-forget; also restarts
    // the local 5-day inactivity reminder. Called from ContactSync.run only.
    //
    // Then tells the server which phone this is (brand, model, Android and app version) and
    // whether the sync was automatic (background = true). The admin "not synced" list and the
    // brand table read this (see add_sync_visibility.sql). If that SQL has not been run yet the
    // second call just fails quietly.
    fun recordSync(context: android.content.Context, userId: String, background: Boolean = false, source: String? = null) {
        InactivityWarningWorker.reschedule(context)
        kotlin.concurrent.thread {
            rpc("record_sync", JSONObject().apply { put("p_user_id", userId) })
            rpc("report_sync_device", JSONObject().apply {
                put("p_user_id", userId)
                put("p_brand", android.os.Build.MANUFACTURER ?: "")
                put("p_model", android.os.Build.MODEL ?: "")
                put("p_sdk", android.os.Build.VERSION.SDK_INT)
                put("p_app_version", BuildConfig.VERSION_CODE)
                put("p_background", background)
                if (source != null) put("p_source", source)
            })
        }
    }

    // The admin switch `sync_adapter_enabled` (SQL: add_sync_adapter.sql). Null = could not ask
    // (offline, or the SQL has not been run yet), so callers keep what the phone remembered.
    // Blocking - call from a background thread.
    fun fetchSyncAdapterEnabled(userId: String): Boolean? {
        val arr = rpc("get_sync_adapter_enabled", JSONObject().apply { put("p_user_id", userId) }) ?: return null
        if (arr.length() == 0) return null
        return arr.getJSONObject(0).optBoolean("enabled", false)
    }

    // ---- Delivery tracking (see add_notification_tracking.sql) ----------
    // All three are fire-and-forget: a failed receipt must never affect the app.

    private fun fireAndForget(name: String, params: JSONObject) {
        kotlin.concurrent.thread { rpc(name, params) }
    }

    // A push arrived while the app was in the foreground.
    fun recordNotificationDelivered(userId: String, notificationId: String) {
        fireAndForget("record_notification_delivered", JSONObject().apply {
            put("p_user_id", userId)
            put("p_notification_id", notificationId)
        })
    }

    // The user tapped a push (this also proves it was delivered).
    fun recordNotificationOpened(userId: String, notificationId: String) {
        fireAndForget("record_notification_opened", JSONObject().apply {
            put("p_user_id", userId)
            put("p_notification_id", notificationId)
        })
    }

    // Whether Android currently lets this app show notifications.
    fun reportNotificationsEnabled(userId: String, enabled: Boolean, callback: (Boolean) -> Unit) {
        kotlin.concurrent.thread {
            callback(rpc("report_notifications_enabled", JSONObject().apply {
                put("p_user_id", userId)
                put("p_enabled", enabled)
            }) != null)
        }
    }

    // Marks every notification currently visible to this user as read
    // (called when they open the Notifications screen), via the
    // mark_notifications_read RPC.
    fun markNotificationsRead(userId: String, callback: (Boolean) -> Unit) {
        callback(rpc("mark_notifications_read", JSONObject().apply { put("p_user_id", userId) }) != null)
    }

    // One value from the app_settings table (null if missing / offline).
    fun fetchSetting(key: String, callback: (String?) -> Unit) {
        val arr = rpc("get_app_setting", JSONObject().apply { put("p_key", key) })
        callback(if (arr != null && arr.length() > 0) arr.getJSONObject(0).optString("value").ifBlank { null } else null)
    }

    // What the admin wants every user to see (notice and/or Maintenance mode).
    // callback(notice, failed): notice is null when there is nothing to show; failed = the call
    // itself failed (offline, server error), so the caller keeps whatever it showed before.
    fun fetchNotice(callback: (Notice?, Boolean) -> Unit) {
        val arr = rpc("get_notice", JSONObject())
        if (arr == null) {
            callback(null, true)
            return
        }
        if (arr.length() == 0) {
            callback(null, false)
            return
        }
        val row = arr.getJSONObject(0)
        val message = row.optString("message").trim()
        callback(if (message.isBlank()) null else Notice(message, row.optBoolean("paused", false)), false)
    }

    // The newest published build, from get_app_update (see add_app_update.sql).
    fun fetchAppUpdate(build: Int, callback: (JSONObject?) -> Unit) {
        val arr = rpc("get_app_update", JSONObject().apply { put("p_current_build", build) })
        callback(if (arr != null && arr.length() > 0) arr.getJSONObject(0) else null)
    }

    // Account status + viewers via get_home. Blocking - call from a background thread.
    fun fetchHome(userId: String, callback: (Boolean, HomeData?) -> Unit) {
        val arr = rpc("get_home", JSONObject().apply { put("p_user_id", userId) })
        if (arr == null || arr.length() == 0) {
            callback(false, null)
            return
        }
        val it = arr.getJSONObject(0)
        callback(true, HomeData(
            status = it.optString("status", "pending"),
            freeCurrent = it.optInt("free_current", 0),
            freeMax = it.optInt("free_max", 0),
            extraCurrent = it.optInt("extra_current", 0),
            extraMax = it.optInt("extra_max", 0),
            referralCount = it.optInt("referral_count", 0),
            verifiedReposts = it.optInt("verified_reposts", 0)
        ))
    }

    // Today's repost status: null, "pending", "verified" or "rejected".
    fun fetchTodayRepostStatus(userId: String, callback: (Boolean, String?) -> Unit) {
        val arr = rpc("get_today_repost_status", JSONObject().apply { put("p_user_id", userId) })
        if (arr == null) {
            callback(false, null)
            return
        }
        callback(true, if (arr.length() > 0) arr.getJSONObject(0).optString("status").ifBlank { null } else null)
    }

    // Phone number of the account that referred this user (null = none or failed).
    // Server function get_my_referrer (supabase/migrations/add_get_my_referrer.sql).
    fun fetchMyReferrerPhone(userId: String): String? {
        if (userId.isBlank()) return null
        val arr = rpc("get_my_referrer", JSONObject().apply { put("p_user_id", userId) })
        if (arr == null || arr.length() == 0) return null
        val o = arr.getJSONObject(0)
        return if (o.isNull("phone")) null else o.optString("phone", "").ifBlank { null }
    }

    // Does the account that referred this user really exist? true = yes, false = no such
    // referrer (the saved "referred by" text is stale), null = the call failed.
    fun fetchMyReferrerExists(userId: String): Boolean? {
        if (userId.isBlank()) return null
        val arr = rpc("get_my_referrer", JSONObject().apply { put("p_user_id", userId) }) ?: return null
        return arr.length() > 0
    }

    // Date registered + referred by for accounts that logged in before
    // those were being saved (see SessionManager.saveRegistrationFrom).
    fun fetchUserProfile(userId: String, callback: (Boolean, JSONObject?) -> Unit) {
        if (userId.isBlank()) {
            callback(false, null)
            return
        }
        val arr = rpc("get_my_profile", JSONObject().apply { put("p_user_id", userId) })
        if (arr != null && arr.length() > 0) callback(true, arr.getJSONObject(0)) else callback(false, null)
    }
}
